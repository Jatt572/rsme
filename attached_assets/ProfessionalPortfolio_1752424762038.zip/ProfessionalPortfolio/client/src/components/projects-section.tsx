import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Building, Wifi, Shield, Video, CheckCircle } from "lucide-react";

export default function ProjectsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  const projectFeatures = [
    {
      icon: Wifi,
      title: "Network Infrastructure",
      description: "Installed and configured access points for seamless connectivity"
    },
    {
      icon: Shield,
      title: "Security Systems", 
      description: "Implemented firewall protection and security cameras"
    },
    {
      icon: Video,
      title: "Smart Systems",
      description: "Deployed smart TVs and conference room setups"
    }
  ];

  const achievements = [
    "Complete infrastructure deployment",
    "Seamless network connectivity",
    "Enhanced security implementation", 
    "Modern conference room technology"
  ];

  return (
    <section id="projects" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-dark mb-6">Key Projects</h2>
          <p className="text-xl text-secondary max-w-3xl mx-auto">
            Featured project showcasing comprehensive IT infrastructure implementation
          </p>
        </motion.div>
        
        <div className="max-w-4xl mx-auto">
          <motion.div 
            className="bg-gradient-to-br from-primary to-accent rounded-2xl shadow-2xl text-white overflow-hidden"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="p-6 sm:p-8 md:p-12">
              <motion.div 
                className="flex flex-col sm:flex-row sm:items-center mb-6"
                initial={{ opacity: 0, x: -30 }}
                animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <Building size={40} className="mb-2 sm:mb-0 sm:mr-4 sm:size-12" />
                <h3 className="text-2xl sm:text-3xl font-bold">Complete Office Setup</h3>
              </motion.div>
              
              <motion.p 
                className="text-base sm:text-lg md:text-xl mb-6 sm:mb-8 text-blue-100 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                Successfully designed and implemented a complete office infrastructure for a new city branch, 
                including all networking, security, and communication systems.
              </motion.p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
                {projectFeatures.map((feature, index) => {
                  const IconComponent = feature.icon;
                  return (
                    <motion.div 
                      key={feature.title}
                      className="bg-white/10 backdrop-blur-sm rounded-lg p-4 sm:p-6"
                      initial={{ opacity: 0, y: 30 }}
                      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                      transition={{ duration: 0.6, delay: 0.8 + index * 0.1 }}
                    >
                      <IconComponent size={28} className="mb-3 sm:mb-4 sm:size-8" />
                      <h4 className="text-base sm:text-lg font-bold mb-2">{feature.title}</h4>
                      <p className="text-xs sm:text-sm text-blue-100">{feature.description}</p>
                    </motion.div>
                  );
                })}
              </div>
              
              <motion.div 
                className="pt-8 border-t border-white/20"
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.6, delay: 1.2 }}
              >
                <h4 className="text-lg sm:text-xl font-bold mb-4">Project Achievements</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                  {achievements.map((achievement, index) => (
                    <motion.div 
                      key={achievement}
                      className="flex items-center"
                      initial={{ opacity: 0, x: 20 }}
                      animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                      transition={{ duration: 0.6, delay: 1.4 + index * 0.1 }}
                    >
                      <CheckCircle size={20} className="mr-3 flex-shrink-0" />
                      <span>{achievement}</span>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
