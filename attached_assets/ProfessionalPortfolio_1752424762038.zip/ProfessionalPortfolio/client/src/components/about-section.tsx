import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { CheckCircle, GraduationCap, Laptop } from "lucide-react";

export default function AboutSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  const achievements = [
    "Expert in troubleshooting hardware/software issues",
    "Cybersecurity practices implementation",
    "IT procurement and vendor coordination",
    "macOS, Windows, and Linux platform expertise"
  ];

  return (
    <section id="about" className="py-16 bg-gray-50" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-dark mb-6">About Me</h2>
          <p className="text-lg sm:text-xl text-secondary max-w-3xl mx-auto">
            Experienced IT Engineer with expertise in infrastructure management, cybersecurity, and cross-platform support
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="order-2 md:order-1"
          >
            <div className="bg-gradient-to-br from-primary to-accent rounded-2xl p-6 sm:p-8 text-white">
              <div className="text-center">
                <Laptop size={72} className="mx-auto mb-4 sm:mb-6 opacity-80 sm:size-24" />
                <h3 className="text-xl sm:text-2xl font-bold">IT Infrastructure Expert</h3>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="order-1 md:order-2"
          >
            <h3 className="text-2xl sm:text-3xl font-bold text-dark mb-4 sm:mb-6">Professional Summary</h3>
            <p className="text-base sm:text-lg text-gray-700 mb-4 sm:mb-6 leading-relaxed">
              Dynamic and results-driven IT Engineer with a Bachelor of Computer Applications (BCA) from 
              Bhagawan Mahavir University and over 2 years of hands-on experience in managing IT infrastructure and operations.
            </p>
            
            <div className="space-y-3 mb-6">
              {achievements.map((achievement, index) => (
                <motion.div 
                  key={index}
                  className="flex items-center"
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
                >
                  <CheckCircle size={18} className="text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-sm sm:text-base">{achievement}</span>
                </motion.div>
              ))}
            </div>
            
            <motion.div 
              className="bg-white rounded-lg shadow-lg p-4 sm:p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: 0.8 }}
            >
              <h4 className="text-lg sm:text-xl font-bold text-dark mb-3 flex items-center">
                <GraduationCap size={20} className="text-primary mr-2 sm:size-6" />
                Education
              </h4>
              <div className="border-l-4 border-primary pl-4">
                <h5 className="font-semibold text-dark text-sm sm:text-base">Bachelor of Computer Applications (BCA)</h5>
                <p className="text-secondary text-sm">Bhagawan Mahavir University, Surat</p>
                <p className="text-xs sm:text-sm text-gray-500">Graduated: 2024</p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}