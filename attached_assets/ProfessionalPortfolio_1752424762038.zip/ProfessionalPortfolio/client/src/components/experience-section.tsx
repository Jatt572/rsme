import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Users, Shield, Wrench, CheckCircle } from "lucide-react";

export default function ExperienceSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  const responsibilities = [
    {
      icon: Users,
      title: "User Management & Administration",
      tasks: [
        "Manage Google Workspace for 500+ users including provisioning and device enrollment",
        "Configure Microsoft 365 Administration: Teams, SharePoint, user accounts",
        "Administer Slack workspace settings and user management"
      ]
    },
    {
      icon: Shield,
      title: "Infrastructure & Security",
      tasks: [
        "Enhanced security with firewalls, VPNs, and access control systems",
        "Optimized network infrastructure and implemented new technologies",
        "Integrated fixed wireless connectivity for high-speed networks"
      ]
    }
  ];

  const supportTasks = [
    "Provide IT support across macOS, Windows, and Linux platforms",
    "Resolve hardware and software issues to maintain high availability",
    "Create and maintain IT procedures documentation",
    "Improved system efficiency through infrastructure optimization"
  ];

  return (
    <section id="experience" className="py-16 bg-gray-50" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-dark mb-6">Professional Experience</h2>
          <p className="text-lg sm:text-xl text-secondary max-w-3xl mx-auto">
            Proven track record in IT infrastructure management and user support
          </p>
        </motion.div>
        
        <div className="max-w-4xl mx-auto">
          <motion.div 
            className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 md:p-12"
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 sm:mb-8">
              <div>
                <h3 className="text-2xl sm:text-3xl font-bold text-dark mb-2">IT Engineer</h3>
                <h4 className="text-lg sm:text-xl text-primary font-semibold mb-1">HotelKey India Private Limited</h4>
                <p className="text-secondary">Surat, Gujarat</p>
              </div>
              <div className="mt-4 md:mt-0">
                <span className="bg-primary text-white px-3 sm:px-4 py-2 rounded-full text-xs sm:text-sm font-medium">
                  June 2023 - Present
                </span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
              {responsibilities.map((responsibility, index) => {
                const IconComponent = responsibility.icon;
                return (
                  <motion.div
                    key={responsibility.title}
                    initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                    animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                    transition={{ duration: 0.6, delay: 0.4 + index * 0.2 }}
                  >
                    <h5 className="text-base sm:text-lg font-bold text-dark mb-4 flex items-center">
                      <IconComponent size={20} className="text-primary mr-2 sm:size-6" />
                      {responsibility.title}
                    </h5>
                    <ul className="space-y-2 text-gray-700">
                      {responsibility.tasks.map((task, taskIndex) => (
                        <motion.li 
                          key={taskIndex}
                          className="flex items-start"
                          initial={{ opacity: 0, x: 20 }}
                          animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                          transition={{ duration: 0.6, delay: 0.6 + index * 0.2 + taskIndex * 0.1 }}
                        >
                          <CheckCircle size={14} className="text-green-500 mr-3 mt-1 flex-shrink-0" />
                          <span className="text-sm sm:text-base">{task}</span>
                        </motion.li>
                      ))}
                    </ul>
                  </motion.div>
                );
              })}
            </div>
            
            <motion.div 
              className="mt-6 sm:mt-8 pt-6 sm:pt-8 border-t border-gray-200"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: 0.8 }}
            >
              <h5 className="text-base sm:text-lg font-bold text-dark mb-4 flex items-center">
                <Wrench size={20} className="text-primary mr-2 sm:size-6" />
                Support & Maintenance
              </h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                {supportTasks.map((task, index) => (
                  <motion.div 
                    key={index}
                    className="flex items-start"
                    initial={{ opacity: 0, x: 20 }}
                    animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                    transition={{ duration: 0.6, delay: 1 + index * 0.1 }}
                  >
                    <CheckCircle size={14} className="text-green-500 mr-3 mt-1 flex-shrink-0" />
                    <span className="text-gray-700 text-sm sm:text-base">{task}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}