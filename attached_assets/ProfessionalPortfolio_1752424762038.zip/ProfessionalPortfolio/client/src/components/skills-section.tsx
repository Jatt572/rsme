import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Monitor, Network, Settings, Apple, Award, CheckCircle, Shield } from "lucide-react";

export default function SkillsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  const operatingSystems = [
    { name: "macOS", level: 95, label: "Expert" },
    { name: "Windows", level: 90, label: "Advanced" },
    { name: "Linux", level: 85, label: "Proficient" }
  ];

  const networkingSkills = [
    "TCP/IP, LAN/WAN, VLAN setup",
    "DNS, DHCP configuration", 
    "VPN configuration",
    "Firewall setup and management",
    "Network performance monitoring",
    "Wireless network troubleshooting"
  ];

  const softwareTools = [
    "Google Workspace Admin",
    "Microsoft 365 Administration", 
    "Slack Administration",
    "Jira Ticket Management",
    "Remote Desktop Tools",
    "MDM Software"
  ];

  const hardwareExpertise = [
    "Desktops, Laptops, MacBooks",
    "Servers and Network devices",
    "Printers and Smart equipment",
    "Access points and Firewalls",
    "Conference room technology"
  ];

  const macOSTools = [
    { category: "Advanced Diagnostics", tools: ["Disk Utility", "Activity Monitor", "Terminal Commands"] },
    { category: "System Management", tools: ["System upgrades", "Software installations", "Cross-platform support"] }
  ];

  const cybersecuritySkills = [
    "Cybersecurity standards implementation",
    "Firewall configuration",
    "VPN & access control systems", 
    "Endpoint security practices"
  ];

  const itOperations = [
    "IT asset management",
    "Vendor coordination",
    "Cost-effective sourcing",
    "Office IT setup (end-to-end)"
  ];

  return (
    <section id="skills" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-dark mb-6">Technical Skills</h2>
          <p className="text-xl text-secondary max-w-3xl mx-auto">
            Comprehensive expertise in IT Infrastructure, Support, and Procurement
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {/* Operating Systems */}
          <motion.div 
            className="bg-gray-50 rounded-xl p-6 sm:p-8 hover:shadow-lg transition-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <div className="text-center mb-6">
              <Monitor size={48} className="text-primary mb-4 mx-auto" />
              <h3 className="text-xl font-bold text-dark">Operating Systems</h3>
            </div>
            <div className="space-y-4">
              {operatingSystems.map((os, index) => (
                <div key={os.name}>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{os.name}</span>
                    <span className="text-sm text-gray-600">{os.label}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <motion.div 
                      className="bg-primary h-2 rounded-full"
                      initial={{ width: 0 }}
                      animate={isInView ? { width: `${os.level}%` } : { width: 0 }}
                      transition={{ duration: 1, delay: 0.5 + index * 0.2 }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Networking */}
          <motion.div 
            className="bg-gray-50 rounded-xl p-6 sm:p-8 hover:shadow-lg transition-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="text-center mb-6">
              <Network size={48} className="text-accent mb-4 mx-auto" />
              <h3 className="text-xl font-bold text-dark">Networking</h3>
            </div>
            <ul className="space-y-2 text-gray-700">
              {networkingSkills.map((skill, index) => (
                <motion.li 
                  key={skill}
                  className="flex items-start"
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.6, delay: 0.7 + index * 0.1 }}
                >
                  <CheckCircle size={16} className="text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{skill}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* Software & Tools */}
          <motion.div 
            className="bg-gray-50 rounded-xl p-6 sm:p-8 hover:shadow-lg transition-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="text-center mb-6">
              <Settings size={48} className="text-secondary mb-4 mx-auto" />
              <h3 className="text-xl font-bold text-dark">Software & Tools</h3>
            </div>
            <ul className="space-y-2 text-gray-700">
              {softwareTools.map((tool, index) => (
                <motion.li 
                  key={tool}
                  className="flex items-start"
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.6, delay: 0.8 + index * 0.1 }}
                >
                  <CheckCircle size={16} className="text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{tool}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* Hardware Expertise */}
          <motion.div 
            className="bg-gray-50 rounded-xl p-6 sm:p-8 hover:shadow-lg transition-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <div className="text-center mb-6">
              <Settings size={48} className="text-primary mb-4 mx-auto" />
              <h3 className="text-xl font-bold text-dark">Hardware Expertise</h3>
            </div>
            <ul className="space-y-2 text-gray-700">
              {hardwareExpertise.map((hardware, index) => (
                <motion.li 
                  key={hardware}
                  className="flex items-start"
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.6, delay: 0.9 + index * 0.1 }}
                >
                  <CheckCircle size={16} className="text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{hardware}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* Cybersecurity */}
          <motion.div 
            className="bg-red-50 rounded-xl p-6 sm:p-8 hover:shadow-lg transition-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.5 }}
          >
            <div className="text-center mb-6">
              <Shield size={48} className="text-red-600 mb-4 mx-auto" />
              <h3 className="text-xl font-bold text-dark">Cybersecurity</h3>
            </div>
            <ul className="space-y-2 text-gray-700">
              {cybersecuritySkills.map((skill, index) => (
                <motion.li 
                  key={skill}
                  className="flex items-start"
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.6, delay: 1.0 + index * 0.1 }}
                >
                  <CheckCircle size={16} className="text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{skill}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* IT Operations & Procurement */}
          <motion.div 
            className="bg-blue-50 rounded-xl p-6 sm:p-8 hover:shadow-lg transition-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <div className="text-center mb-6">
              <Settings size={48} className="text-blue-600 mb-4 mx-auto" />
              <h3 className="text-xl font-bold text-dark">IT Operations</h3>
            </div>
            <ul className="space-y-2 text-gray-700">
              {itOperations.map((operation, index) => (
                <motion.li 
                  key={operation}
                  className="flex items-start"
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.6, delay: 1.1 + index * 0.1 }}
                >
                  <CheckCircle size={16} className="text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{operation}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* macOS Troubleshooting */}
          <motion.div 
            className="bg-gradient-to-br from-primary to-accent rounded-xl p-6 sm:p-8 text-white hover:shadow-lg transition-shadow sm:col-span-2 lg:col-span-2"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.7 }}
          >
            <div className="text-center mb-6">
              <Apple size={48} className="mb-4 mx-auto" />
              <h3 className="text-xl font-bold">macOS Troubleshooting Expertise</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              {macOSTools.map((category, index) => (
                <div key={category.category}>
                  <h4 className="font-semibold mb-3">{category.category}</h4>
                  <ul className="space-y-2 text-blue-100">
                    {category.tools.map((tool, toolIndex) => (
                      <motion.li 
                        key={tool}
                        className="flex items-center"
                        initial={{ opacity: 0, x: 20 }}
                        animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                        transition={{ duration: 0.6, delay: 1.2 + index * 0.2 + toolIndex * 0.1 }}
                      >
                        <Settings size={16} className="mr-2 flex-shrink-0" />
                        <span className="text-sm">{tool}</span>
                      </motion.li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Certifications */}
          <motion.div 
            className="bg-green-50 rounded-xl p-6 sm:p-8 hover:shadow-lg transition-shadow"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <div className="text-center mb-6">
              <Award size={48} className="text-green-600 mb-4 mx-auto" />
              <h3 className="text-xl font-bold text-dark">Certifications</h3>
            </div>
            <div className="text-center">
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h4 className="font-bold text-dark mb-2">Advanced Diploma in Cybersecurity Standards</h4>
                <p className="text-sm text-gray-600">PureSkill IT Training Academy AIMCVT</p>
                <p className="text-xs text-green-600 mt-1">Issued: May 2023</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
