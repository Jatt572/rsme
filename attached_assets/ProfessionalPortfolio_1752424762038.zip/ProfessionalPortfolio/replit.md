# Replit.md

## Overview

This is a full-stack web application featuring a professional portfolio website for IT Engineer Jatin Chauhan. The application is built with a modern React frontend and Express.js backend, showcasing professional experience, comprehensive technical skills, and providing a contact form functionality. The project uses TypeScript throughout and implements a fully responsive design optimized for mobile, tablet, and desktop devices with Tailwind CSS and shadcn/ui components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Animation**: Framer Motion for smooth animations and interactions
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API**: RESTful API design with proper error handling
- **Storage**: Dual storage implementation (Memory storage for development, with Drizzle ORM setup for PostgreSQL)
- **Session Management**: Ready for PostgreSQL session storage with connect-pg-simple

### Component Structure
The frontend follows a modular component structure:
- Page components (`pages/`) handle routing and overall page layout
- Feature components (`components/`) handle specific sections (hero, about, skills, experience, projects, contact)
- UI components (`components/ui/`) provide reusable design system elements from shadcn/ui

## Key Components

### Database Schema (Drizzle ORM)
- **Users Table**: Basic user management with username/password
- **Contact Submissions Table**: Stores contact form submissions with timestamps
- **Schema Validation**: Zod schemas for type-safe data validation

### API Endpoints
- `POST /api/contact` - Submit contact form
- `GET /api/contact-submissions` - Retrieve all contact submissions (admin endpoint)

### Storage Layer
- **Interface-based Design**: `IStorage` interface allows switching between memory and database storage
- **Memory Storage**: In-memory implementation for development
- **Database Storage**: Configured for PostgreSQL via Drizzle ORM

### UI Component System
- **shadcn/ui Integration**: Complete UI component library with consistent theming
- **Fully Responsive Design**: Mobile-first approach with comprehensive responsive breakpoints (sm, md, lg)
- **Cross-Device Optimization**: Optimized layouts for mobile phones, tablets, and desktop computers
- **Touch-Friendly Interface**: Mobile-optimized button sizes, spacing, and navigation
- **Responsive Typography**: Fluid text sizing across all screen sizes
- **Form Handling**: React Hook Form with Zod validation

## Data Flow

1. **Contact Form Submission**:
   - User fills contact form → Form validation (client-side) → API request → Server validation → Database storage → Success response

2. **Portfolio Display**:
   - Static content rendered from React components → Smooth animations via Framer Motion → Responsive layout via Tailwind CSS

3. **Navigation**:
   - Smooth scrolling between sections → Mobile-responsive navigation menu → Active section highlighting

## External Dependencies

### Core Dependencies
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM for type-safe database operations
- **UI Framework**: Radix UI primitives for accessibility
- **Animation**: Framer Motion for smooth transitions
- **Form Management**: React Hook Form with Hookform resolvers
- **Validation**: Zod for schema validation
- **Styling**: Tailwind CSS with PostCSS

### Development Dependencies
- **Build**: Vite with React plugin
- **TypeScript**: Full TypeScript support throughout
- **ESBuild**: For backend bundling in production

## Deployment Strategy

### Development Environment
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx for TypeScript execution with nodemon-like behavior
- **Database**: Configured for DATABASE_URL environment variable

### Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: ESBuild bundles Express server to `dist/index.js`
- **Static Serving**: Express serves built frontend in production
- **Environment**: NODE_ENV-based configuration

### Database Deployment
- **Migrations**: Drizzle Kit for database schema management
- **Connection**: PostgreSQL via environment variable configuration
- **Session Storage**: Ready for production session management

### Key Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `NODE_ENV`: Environment flag for development/production behavior

## Recent Changes

### January 2025 - Responsive Design Implementation
- **Complete Mobile Optimization**: Enhanced all components for mobile-first responsive design
- **Comprehensive Skills Update**: Updated skills section with detailed technical expertise from resume
- **Cross-Device Testing**: Optimized layouts for smartphones, tablets, and desktop computers  
- **Touch Interface**: Improved navigation and buttons for touch devices
- **Typography Scaling**: Implemented fluid responsive typography across all sections
- **Layout Improvements**: Fixed spacing issues and enhanced visual hierarchy

The application is designed for easy deployment on platforms like Replit, with automatic environment detection and proper static file serving in production mode.